<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

ERROR - 2021-07-26 03:17:43 --> Severity: error --> Exception: syntax error, unexpected '"klasifikasi_surat"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\pdd\sidepeapps\models\Database_model.php 5057
ERROR - 2021-07-26 03:20:13 --> Severity: error --> Exception: syntax error, unexpected '"klasifikasi_surat"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\pdd\sidepeapps\models\Database_model.php 5057
ERROR - 2021-07-26 03:20:35 --> Severity: error --> Exception: syntax error, unexpected '"klasifikasi_surat"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\pdd\sidepeapps\models\Database_model.php 5057
ERROR - 2021-07-26 00:16:02 --> 404 Page Not Found: Privacy-policy/index
ERROR - 2021-07-26 00:18:37 --> 404 Page Not Found: Privacy-policy/index
ERROR - 2021-07-26 00:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-26 01:13:05 --> 404 Page Not Found: Privacy-policy/index
ERROR - 2021-07-26 01:16:03 --> 404 Page Not Found: Privacy-policy/index
ERROR - 2021-07-26 13:16:34 --> Query error: Duplicate entry '0-042-Pulo_Sari' for key 'rt' - Invalid query: INSERT INTO `tweb_wil_clusterdesa` (`rw`, `id_kepala`, `dusun`) VALUES ('042', '-- Silakan Masukan NIK / Nama--', 'Pulo_Sari')
ERROR - 2021-07-26 07:28:06 --> 404 Page Not Found: Desa/upload
ERROR - 2021-07-26 07:28:16 --> 404 Page Not Found: Desa/upload
ERROR - 2021-07-26 07:28:25 --> 404 Page Not Found: Desa/upload
ERROR - 2021-07-26 07:29:07 --> 404 Page Not Found: Privacy-policy/index