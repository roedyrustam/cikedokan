<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-09 03:54:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 03:54:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 03:54:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:48 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:48 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:48 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:49 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:49 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:49 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:50 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:50 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 21:05:50 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 22:28:31 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 22:28:31 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 22:28:31 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-09 22:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-09 22:46:14 --> 404 Page Not Found: Well-known/assetlinks.json
