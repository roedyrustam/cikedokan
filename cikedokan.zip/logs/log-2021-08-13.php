<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-13 13:05:12 --> Unable to connect to the database
ERROR - 2021-08-13 13:05:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/logo
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:23:14 --> 404 Page Not Found: Desa/logo
ERROR - 2021-08-13 13:23:15 --> 404 Page Not Found: Desa/logo
ERROR - 2021-08-13 13:24:28 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:28 --> 404 Page Not Found: Desa/logo
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/logo
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:24:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:28:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:28:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:28:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:28:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:28:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-13 13:28:59 --> 404 Page Not Found: Desa/upload
