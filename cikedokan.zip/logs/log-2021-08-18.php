<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-18 18:36:54 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-18 18:36:54 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-18 18:36:54 --> 404 Page Not Found: Desa/upload
