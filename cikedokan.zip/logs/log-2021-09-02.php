<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-02 13:39:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-02 13:39:29 --> 404 Page Not Found: Desa/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-02 13:39:29 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-02 13:39:31 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-02 13:39:31 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-02 13:39:31 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-02 22:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-02 22:52:26 --> 404 Page Not Found: Well-known/assetlinks.json
