<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-26 10:15:04 --> 404 Page Not Found: Desa/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-26 10:15:04 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-26 10:15:04 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-26 10:15:07 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-26 10:15:07 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-26 10:15:07 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-26 11:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-26 11:06:04 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-08-26 11:07:24 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-26 23:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-26 23:01:42 --> 404 Page Not Found: Well-known/assetlinks.json
