<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-25 21:17:04 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:17:05 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:17:06 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:20:43 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:20:44 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:28:36 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:28:36 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:28:37 --> 404 Page Not Found: Desa/logo
ERROR - 2021-07-25 21:47:37 --> 404 Page Not Found: Desa/upload
ERROR - 2021-07-25 23:21:56 --> 404 Page Not Found: Assets/bootstrap
