<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-10 17:55:02 --> 404 Page Not Found: Desa/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-10 17:55:02 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:55:02 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:55:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:55:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:55:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:56:56 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:56:56 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:56:56 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:56:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:56:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 17:56:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-10 23:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:14:52 --> 404 Page Not Found: Well-known/assetlinks.json
