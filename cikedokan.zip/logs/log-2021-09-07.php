<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-07 18:15:44 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:44 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:44 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:47 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:47 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:47 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:50 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:50 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 18:15:50 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-07 22:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-07 22:44:20 --> 404 Page Not Found: Well-known/assetlinks.json
