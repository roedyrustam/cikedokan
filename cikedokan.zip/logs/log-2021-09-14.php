<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 22:24:58 --> 404 Page Not Found: Desa/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 22:24:58 --> 404 Page Not Found: Desa/upload
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-14 22:24:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:24:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:24:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:24:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:01 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:01 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:01 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:25:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-14 22:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-14 22:48:02 --> 404 Page Not Found: Well-known/assetlinks.json
