<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-04 01:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:29:28 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 11:29:28 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 11:29:28 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:57 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:57 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:57 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:48:59 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 14:49:10 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-04 22:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:45:50 --> 404 Page Not Found: Well-known/assetlinks.json
