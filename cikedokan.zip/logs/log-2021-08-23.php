<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-23 08:00:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-23 18:16:18 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 18:16:18 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 18:16:18 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 18:16:20 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 18:16:20 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 18:16:20 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:41 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:41 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:41 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:41 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:45 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:45 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-23 20:45:45 --> 404 Page Not Found: Desa/upload
