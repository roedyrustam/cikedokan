<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-14 09:56:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 09:56:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 09:56:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 09:56:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 09:56:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 09:56:14 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 10:03:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 10:03:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 10:03:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 10:03:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 10:03:09 --> 404 Page Not Found: Desa/upload
ERROR - 2021-08-14 10:03:09 --> 404 Page Not Found: Desa/upload
