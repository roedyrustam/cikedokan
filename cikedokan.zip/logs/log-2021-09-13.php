<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-13 08:40:01 --> 404 Page Not Found: Env/index
ERROR - 2021-09-13 22:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-13 22:45:38 --> 404 Page Not Found: Well-known/assetlinks.json
