<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-03 22:21:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:21:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:21:58 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:22:06 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:22:06 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:22:06 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:22:08 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:22:08 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 22:22:08 --> 404 Page Not Found: Desa/upload
ERROR - 2021-09-03 23:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-03 23:53:58 --> 404 Page Not Found: Well-known/assetlinks.json
